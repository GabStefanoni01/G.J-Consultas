<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Área do Cliente - Clínica de Saúde XYZ</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="logo">
            <img src="logo.png" alt="Logotipo da Clínica de Saúde XYZ">
        </div>
        <nav>
            <ul>
                <li><a href="index.html">Página Inicial</a></li>
                <li><a href="cadastro.html">Cadastro</a></li>
                <li><a href="login.html">Login</a></li>
                <li><a href="consultas.html">Consultas</a></li>
                <li><a href="exames.html">Exames</a></li>
                <li><a href="ajuda.html">Ajuda</a></li>
                <li><a href="contato.html">Contato</a></li>
                <li><a href="sobre.html">Sobre Nós</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <div class="client-info">
            <h2>Área do Cliente</h2>
            <?php
            // Simulação de informações do cliente
            $clienteNome = "Cliente de Exemplo";
            $clienteEmail = "cliente@example.com";
            $clienteTelefone = "(11) 1234-5678";

            echo "<h3>Informações do Cliente</h3>";
            echo "<p><strong>Nome:</strong> $clienteNome</p>";
            echo "<p><strong>Email:</strong> $clienteEmail</p>";
            echo "<p><strong>Telefone:</strong> $clienteTelefone</p>";
            ?>
        </div>
        <div class="scheduled-appointments">
            <h3>Exames Agendados</h3>
            <ul>
                <?php
                // Simulação de exames agendados
                $examesAgendados = array(
                    array("Data" => "01/12/2023 - 10:00", "Tipo de Exame" => "Ultrassonografia", "Local" => "Unidade Central"),
                    array("Data" => "15/12/2023 - 15:30", "Tipo de Exame" => "Raio-X", "Local" => "Unidade Sul"),
                    // Adicione mais exames agendados conforme necessário
                );

                foreach ($examesAgendados as $exame) {
                    echo "<li><strong>Data:</strong> " . $exame["Data"] . "</li>";
                    echo "<li><strong>Tipo de Exame:</strong> " . $exame["Tipo de Exame"] . "</li>";
                    echo "<li><strong>Local:</strong> " . $exame["Local"] . "</li>";
                }
                ?>
            </ul>
        </div>
    </main>
    <footer>
        <p>&copy; 2023 Clínica de Saúde XYZ. Todos os direitos reservados.</p>
    </footer>
</body>
</html>
